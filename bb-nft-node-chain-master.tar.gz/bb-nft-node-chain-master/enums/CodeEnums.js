function ReturnCodeEnums(code, desc) {
    return {
        getCode() {
            return code;
        },

        getDesc() {
            return desc;
        }
    }
}

module.exports = {
    "ERRORS" : {
        ADDRESS_ERROR: ReturnCodeEnums(900001, "address is error"),
        SIGN_CHECK_ERROR: ReturnCodeEnums(900002, "sign check error"),
        INTERNAL_ERROR: ReturnCodeEnums(900010, "internal error"),
        ESTIMATEGAS_ERROR: ReturnCodeEnums(900020, "estimate error"),
        INVALID_NETWORK: ReturnCodeEnums(900030, "invalid network"),
        INVALID_HASH: ReturnCodeEnums(900040, "invalid tx hash")
    },
    "RESULT" : {
        TX_PENDING: ReturnCodeEnums(901000, "tx is pending"),
        TX_FAILED: ReturnCodeEnums(901001, "tx is failed"),
        TX_SUCCESS: ReturnCodeEnums(901002, "tx is successful")
    }
}

