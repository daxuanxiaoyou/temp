module.exports = {
    success(data, code = 0, msg = null) {
        return {
            ret_code: code,
            ret_msg: msg,
            success: true,
            result: data,
        }
    },

    fail(code, msg) {
        return {
            ret_code: code,
            ret_msg: msg,
            success: false,
        }
    }

}