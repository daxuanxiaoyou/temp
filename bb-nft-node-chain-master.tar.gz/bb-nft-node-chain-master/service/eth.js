const ethSigUtil = require("eth-sig-util");
const ethjs = require("ethereumjs-util");
const Web3 = require('web3');
const math = require('mathjs');
const ethers = require('ethers');
const CODES = require('../enums/CodeEnums');


const PROVIDERS = ['https://rpc.ankr.com/eth', 'https://cloudflare-eth.com/'];

module.exports = {
    /**
     * 校验地址
     * @param address
     * @returns {boolean}
     */
    checkAddress(address) {
        try {
            return ethjs.isValidChecksumAddress(address);
        }catch (e) {
            return false;
        }
    },


    /**
     * 验证签名
     */
    verifySignature(data, sign) {
        // return await web3.eth.personal.ecRecover(data, sign);
        const msgParams = {
            data: data,
            sig: sign
        };

        try {
            return ethSigUtil.recoverPersonalSignature(msgParams);
        }catch (e) {
            return null;
        }

    },

    /**
     * 评估gas
     **/
     async estimateGas(gasLimit) {
        /** 
        * eth不需要判断token是否存在，直接评估safeTransferFrom
        **/
        try {
            const index = Math.floor(Math.random() * 100) % PROVIDERS.length;
            console.log(PROVIDERS[index]);
            const web3 = new Web3(PROVIDERS[index]);
            //get gasPrice
            const gasPrice = await web3.eth.getGasPrice();
            let costBase = math.multiply(gasLimit, gasPrice);
            costBase = ethers.utils.formatEther(costBase);
            //up 20%
            const adjustCost = math.multiply(costBase, 1.2);
            return adjustCost.toString();
        } catch (e) {
            throw e;
        }
    },

    /**
     * check tx status
     **/
     async txStatus(hash) {
        try {
            const index = Math.floor(Math.random() * 100) % PROVIDERS.length;
            const web3 = new Web3(PROVIDERS[index]);
            if (hash.length != 66 || !hash.startsWith('0x')) {
                return CODES.ERRORS.INVALID_HASH;
            }

            const result = web3.eth.getTransactionReceipt(hash).then((receipt) => {

                if (receipt == null || receipt == undefined) {
                    //pending state
                    return CODES.RESULT.TX_PENDING;
                }
                
                //success
                if (receipt.status == 1) {
                    return CODES.RESULT.TX_SUCCESS;
                }
                //failed
                return CODES.RESULT.TX_FAILED;

            });
            return result;
        } catch (e) {
            throw e;
        }
    }
}
