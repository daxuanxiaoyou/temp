const pinataSDK = require('@pinata/sdk');

let PinataApiKey = '87b3b78013ef0f1cf8cf';
let PinataSecretApiKey = 'b1716806929742442cae7e190a27a4b391718c209fa2d6037cf7dac43990504a';

const Creators = ['tz1KeX2ubekRRoCGZhzcx3N7VJXh9rzdHCrC'];

function makeJson(name, symbol, dec, type, imageUrl, thumbnailUri) {
    let data = {};
    let fullType;
    switch (type) {
        case 'png':
        case 'jpg':
        case 'jpeg':
        case 'gif':
            fullType = 'image/' + type;
            break;
        case 'mp4':
            fullType = 'video/' + type;
            break;
        default:
            fullType = type;
            break;
    }
    /*build json*/
    data['name'] = name;
    data['symbol'] = symbol;
    data['description'] = dec;
    data['type'] = fullType;
    data['decimals'] = 0;
    data['isBooleanAmount'] = true;
    data['creators'] = Creators;
    data['artifactUri'] = imageUrl;
    data['displayUri'] = imageUrl;
    data['thumbnailUri'] = thumbnailUri;

    let dataJson = JSON.stringify(data, null, 2);

    return  dataJson;
    
}

async function uploadFile(tokenId, name, symbol, dec, type, imageUrl, thumbnailUri) {
    const pinata = pinataSDK(PinataApiKey, PinataSecretApiKey);
    var filename = tokenId.toString();

    let upload = pinata.testAuthentication().then(result => {
        var uri = null;
        if (result.authenticated == true) {
            const options = {
                pinataMetadata: {
                    name: filename,
                },
                pinataOptions: {
                    cidVersion: 0
                }
            };
            let dataJson = makeJson(name, symbol, dec, type, imageUrl, thumbnailUri);
            let body = JSON.parse(dataJson);
            uri = pinata.pinJSONToIPFS(body, options).then((result) => {
                return result.IpfsHash;
            }).catch((err) => {
                throw err;
            });      
        }
        return uri;

    }).catch((err) => {
        throw err;
    });

    return  upload;
}

exports.uploadFile = uploadFile;
