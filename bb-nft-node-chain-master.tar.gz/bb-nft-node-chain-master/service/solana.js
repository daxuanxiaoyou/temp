const Web3 = require('@solana/web3.js');
const bs58 = require('bs58');
const CODES = require('../enums/CodeEnums');


const MULTI_SINGERS = 3;

module.exports = {

    /**
     * 校验地址
     * @param address
     * @returns {boolean}
     */
    checkAddress(address) {
        try {
            let pubkey = new Web3.PublicKey(address);
            let isSolana =  Web3.PublicKey.isOnCurve(pubkey.toBuffer());
            return isSolana;
        } catch (error) {
            return false;
        }
    },
    /**
     * 校验地址
     * @param address
     * @returns {boolean}
     */
    async estimateGas() {
        try {
            const connection = new Web3.Connection(
                Web3.clusterApiUrl('mainnet-beta')
            );

            const payer = Web3.Keypair.generate();
            const to = Web3.Keypair.generate();

            const transaction = new Web3.Transaction();
            transaction.add(
              Web3.SystemProgram.transfer({
                fromPubkey: payer.publicKey,
                toPubkey: to.publicKey,
                lamports: Web3.LAMPORTS_PER_SOL * 1,
              })
            );
 
            //2. set lastest block
            const blockinfo = await connection.getLatestBlockhash('finalized');
            transaction.recentBlockhash = blockinfo.blockhash;
            //3. set feePayer
            transaction.feePayer = payer.publicKey;
            //estimated fee
            const response = await connection.getFeeForMessage(
              transaction.compileMessage(),
              'confirmed',
            );
            //get the fee 
            let fee =  response.value;
            fee = MULTI_SINGERS * fee / Web3.LAMPORTS_PER_SOL;
            return fee.toString();
        } catch (e) {
            throw e;
        }
    },

    /**
     * check tx status
     **/
    async txStatus(hash) {
      try {
          let decodedSignature;

          const connection = new Web3.Connection(
            Web3.clusterApiUrl('mainnet-beta')
          );
          
          //check hash
          try {
              decodedSignature = bs58.decode(hash);
          } catch (err) {
              return CODES.ERRORS.INVALID_HASH;
          }

          if (decodedSignature.length != 64) {
            return CODES.ERRORS.INVALID_HASH;
          }
      
          const result = connection.getSignatureStatus(hash).then((receipt) => {
              if (receipt.value == null || receipt.value == undefined) {
                  //pending state
                  return CODES.RESULT.TX_PENDING;
              }

              if (receipt.value.confirmationStatus === 'processed') {
                  //pending state
                  return CODES.RESULT.TX_PENDING;
              }
              
              //success
              if (receipt.value.err == null) {
                  return CODES.RESULT.TX_SUCCESS;
              }
              //failed
              return CODES.RESULT.TX_FAILED;

          });
          return result;
      } catch (e) {
          throw e;
      }
  }
}