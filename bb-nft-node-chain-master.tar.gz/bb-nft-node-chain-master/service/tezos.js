"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isMint = exports.getTokenMetadata = void 0;
const taquito_1 = require("@taquito/taquito");
const tzip16_1 = require("@taquito/tzip16");
const node_fetch_1 = __importDefault(require("node-fetch"));
const https_proxy_agent_1 = __importDefault(require("https-proxy-agent"));
const utils_1 = require("@taquito/utils");
const conseiljs_1 = require('conseiljs');
const log = require('loglevel');
const CODES = require('../enums/CodeEnums');

const logger = log.getLogger('tezos');
logger.setLevel('error', false);
conseiljs_1.registerLogger(logger);

const rpcProviders = {
    main: "https://mainnet.smartpy.io",
    test: "https://jakartanet.smartpy.io"
};
const singer_1 = require("@taquito/signer");
const { forEach } = require("mathjs");

class MyIpfsHandler {
    constructor(ipfsGatheway) {
        this._ipfsGateway = ipfsGatheway ? ipfsGatheway : 'ipfs.io';
    }
    getMetadata(_contractAbstraction, { location }, _context) {
        return __awaiter(this, void 0, void 0, function* () {
            const fetchParam = {
                method: 'GET'
            };
            let info = yield (0, node_fetch_1.default)(`https://${this._ipfsGateway}/ipfs/${location.substring(2)}/`, fetchParam);
            let str = yield info.text();
            // @ts-ignore
            return Promise.resolve(str);
        });
    }
}
function getTezos(network) {
    const tezos = new taquito_1.TezosToolkit(rpcProviders[network]);
    try {
        const myhandler = new Map([
            ['http', new tzip16_1.HttpHandler()],
            ['https', new tzip16_1.HttpHandler()],
            ['tezos-storage', new tzip16_1.TezosStorageHandler()],
            ['ipfs', new MyIpfsHandler('gateway.pinata.cloud')]
        ]);
        tezos.addExtension(new tzip16_1.Tzip16Module(new tzip16_1.MetadataProvider(myhandler)));
    }
    catch (ex) {
        throw ex;
    }
    return tezos;
}

const tokenMetadataRegex = /\"token_metadata\":\"([0-9]+)\"/;
const ledgerExRegex = /\"ledger_ex\":\"([0-9]+)\"/;
const allTokenRegex = /\"all_tokens\":\"([0-9]+)\"/;
//api.better-call api is not public, delete it
const ApiUrlMap = {
    map: {
        0: 'https://api.tzkt.io/v1/bigmaps/',
        1: 'https://api.tzstats.com/explorer/bigmap/',
    },
    operation: {
        0: 'https://api.tzkt.io/v1/operations/transactions/',
        1: 'https://api.tzstats.com/explorer/op/',
    }
};
//store bigMap Ids fo all contract
/*
BigMaps = new Map()
    main_KT1...._token_metadata --> 77100
    test_KT1...._token_metadata --> 88100
*/
const BigMaps = new Map();
//random paras
const MAX_INDEX = 100;
//api.better-call.dev is not public, so delete it
const MOD = 2;

function getBigMapId(network, contractAddr, name) {
    return __awaiter(this, void 0, void 0, function* () {
        let tezos = getTezos(network);
        let key;
        let scheme;
        switch (name) {
            case 'token_metadata':
                key = network + '_' + contractAddr.toString() + '_token_metadata';
                scheme = tokenMetadataRegex;
                break;
            case 'ledger_ex':
                key = network + '_' + contractAddr.toString() + '_ledger_ex';
                scheme = ledgerExRegex;
                break;
            default:
                throw 'Wrong bigMap';
        }
        var bigmapID = BigMaps.get(key);
        if (bigmapID != undefined) {
            return bigmapID;
        }
        if ((0, utils_1.validateContractAddress)(contractAddr) === 3) {
            try {
                const contract = yield tezos.contract.at(contractAddr, tzip16_1.tzip16);
                const storage = yield contract.storage();
                if (scheme.test(JSON.stringify(storage))) {
                    const match = JSON.stringify(storage).match(scheme);
                    if (match) {
                        bigmapID = match[1].toString();
                        BigMaps.set(key, bigmapID);
                    }
                }
            }
            catch (ex) {
                throw ex;
            }
        }
        return bigmapID;
    });
}
function getTokenMetadataBigMapId(network, contractAddr) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let id = yield getBigMapId(network, contractAddr, 'token_metadata');
            return id;
        }
        catch (e) {
            throw e;
        }
    });
}
function getLedgerExBigMapId(network, contractAddr) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let id = yield getBigMapId(network, contractAddr, 'ledger_ex');
            return id;
        }
        catch (e) {
            throw e;
        }
    });
}
function getRandomInt(max, mod) {
    return Math.floor(Math.random() * max) % mod;
}
function getBaseUrl(attr, index) {
    if (index >= MOD) {
        index = 0;
    }
    switch (attr) {
        case 'map':
            return ApiUrlMap.map[index];
        case 'operation':
            return ApiUrlMap.operation[index];
        default:
            throw 'error attr';
    }
}
/*
true -- 已经mint过了
false -- 还没mint
*/
function isMint(network, address, tokenId) {
    return __awaiter(this, void 0, void 0, function* () {
        if ((0, utils_1.validateContractAddress)(address) === 3) {
            try {
                let id = yield getTokenMetadataBigMapId(network, address);
                let index = getRandomInt(MAX_INDEX, MOD);
                let url = getBaseUrl('map', index) + id + '/keys';
                let result;
                let tokenIDs;
                const data = yield (0, node_fetch_1.default)(url);
                if (data) {
                    const json = yield data.json();
                    switch (index) {
                        case 0:
                            // @ts-ignore
                            tokenIDs = json.map(el => {
                                if (!isNaN(el.value.token_id)) {
                                    return el.value.token_id;
                                }
                                else {
                                    throw "Invalid token ID";
                                }
                            });
                            result = tokenIDs.findIndex(e => e == tokenId);
                            break;
                        case 1:
                            // @ts-ignore
                            tokenIDs = json.map(el => {
                                if (!isNaN(el.key)) {
                                    return el.key;
                                }
                                else {
                                    throw "Invalid token ID";
                                }
                            });
                            result = tokenIDs.findIndex(e => e == tokenId);
                            break;
                        case 2:
                            // @ts-ignore
                            tokenIDs = json.map(el => {
                                if (!isNaN(el.data.key.value)) {
                                    return el.data.key.value;
                                }
                                else {
                                    throw "Invalid token ID";
                                }
                            });
                            result = tokenIDs.findIndex(e => e == tokenId);
                            break;
                        default:
                            result = -1;
                            break;
                    }
                    if (result >= 0) {
                        return true;
                    }
                }
            }
            catch (ex) {
                throw ex;
            }
        }
        return false;
    });
}
exports.isMint = isMint;
function getBalance(network, address, wallet) {
    return __awaiter(this, void 0, void 0, function* () {
        if ((0, utils_1.validateContractAddress)(address) === 3) {
            try {
                let id = yield getLedgerExBigMapId(network, address);
                let index = getRandomInt(MAX_INDEX, MOD);
                let url;
                let data;
                let len;
                switch (index) {
                    case 0:
                        url = getBaseUrl('map', index) + id + '/keys';
                        data = yield (0, node_fetch_1.default)(url);
                        if (data) {
                            const json = yield data.json();
                            len = json.length;
                            for (var iter = 0; iter < len; iter++) {
                                if (json[iter].key == wallet) {
                                    return json[iter].value;
                                }
                            }
                        }
                        break;
                    case 1:
                        url = getBaseUrl('map', index) + id + '/values';
                        data = yield (0, node_fetch_1.default)(url);
                        if (data) {
                            const json = yield data.json();
                            len = json.length;
                            for (var iter = 0; iter < len; iter++) {
                                if (json[iter].key == wallet) {
                                    return json[iter].value;
                                }
                            }
                        }
                        break;
                    case 2:
                        url = getBaseUrl('map', index) + id + '/keys';
                        data = yield (0, node_fetch_1.default)(url);
                        if (data) {
                            const json = yield data.json();
                            len = json.length;
                            for (var iter = 0; iter < len; iter++) {
                                if (json[iter].data.key.value == wallet) {
                                    const tokenIDs = json[iter].data.value.children.map(el => {
                                        if (!isNaN(el.value)) {
                                            return el.value;
                                        }
                                        else {
                                            throw "Invalid token ID";
                                        }
                                    });
                                    return tokenIDs;
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
            catch (ex) {
                throw ex;
            }
        }
        return null;
    });
}
exports.getBalance = getBalance;
function getTokenMetadata(network, contractAddress, token_id) {
    return __awaiter(this, void 0, void 0, function* () {
        let result = null;
        if ((0, utils_1.validateContractAddress)(contractAddress) === 3) {
            try {
                let id = yield getTokenMetadataBigMapId(network, contractAddress);
                let index = getRandomInt(MAX_INDEX, MOD);
                let url;
                let len;
                let data;
                switch (index) {
                    case 0:
                        url = getBaseUrl('map', index) + id + '/keys';
                        data = yield (0, node_fetch_1.default)(url);
                        if (data) {
                            const json = yield data.json();
                            len = json.length;
                            for (var iter = 0; iter < len; iter++) {
                                if (json[iter].value.token_id == token_id.toString()) {
                                    result = json[iter].value.token_info[''];
                                    result = (0, tzip16_1.bytes2Char)(result);
                                }
                            }
                        }
                        break;
                    case 1:
                        url = getBaseUrl('map', index) + id + '/values';
                        data = yield (0, node_fetch_1.default)(url);
                        if (data) {
                            const json = yield data.json();
                            len = json.length;
                            for (var iter = 0; iter < len; iter++) {
                                if (json[iter].value.token_id == token_id.toString()) {
                                    result = json[iter].value.token_info[''];
                                    result = (0, tzip16_1.bytes2Char)(result);
                                }
                            }
                        }
                        break;
                    case 2:
                        url = getBaseUrl('map', index) + id + '/keys';
                        data = yield (0, node_fetch_1.default)(url);
                        if (data) {
                            const json = yield data.json();
                            len = json.length;
                            for (var iter = 0; iter < len; iter++) {
                                if (json[iter].data.key.value == token_id.toString()) {
                                    result = json[iter].data.value.children[1].children[0].value;
                                }
                            }
                        }
                        break;
                    default:
                        result = null;
                        break;
                }
            }
            catch (ex) {
                throw ex;
            }
        }
        return result;
    });
}
exports.getTokenMetadata = getTokenMetadata;


/**
 * 校验地址
 * @param address
 * @returns {boolean}
 */
function checkAddress(address) {
    try {
        return utils_1.validateAddress(address) == 3;
    }catch (e) {
        return false;
    }
}

exports.checkAddress = checkAddress;


//tezos是自己发的合约，经过评估和链上的真实数据，默认0.11 xtz
//tezos的rpc node不太稳定，没有必要真实从链上获取
var gasFee = 0.11;

function estimateGas() {
    return gasFee.toString();
}

exports.estimateGas = estimateGas;

/*
applied, failed, backtracked, skipped
*/
async function txStatus(hash){
    try {
        let result = 'pending';
        let index = getRandomInt(MAX_INDEX, MOD);
        let url = getBaseUrl('operation', index) + hash;
        const data = await node_fetch_1['default'](url);
        if (data) {
            const json = await data.json();
            const ops = json.filter(op => op.status === 'applied');
            if (ops.length > 0) {
                result = 'applied';
            } else {
                result = 'failed';
            }
        }

        switch (result) {
            case 'applied':
                return CODES.RESULT.TX_SUCCESS;
            case 'pending':
                return CODES.RESULT.TX_PENDING;
            default:
                return CODES.RESULT.TX_FAILED;
        }
    }
    catch (ex) {
        throw ex;
    }
}

exports.txStatus = txStatus;