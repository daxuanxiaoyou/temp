const express = require('express');
const splToken = require('@solana/spl-token');
const metadata = require('@metaplex-foundation/mpl-token-metadata');
const  web3 =  require("@solana/web3.js");


const rpcProviders = {
  SOL: "https://solana-mainnet.phantom.tech"
};

const PROGRAM = "spl-token";
const METAPLEX_ACCOUNT = "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s";

var info = {"address":"0x0","decimals":0, "supply":1, "type":"mint", "program":"spl-token", "result":0};

module.exports = {
    /**
     * 校验owner是否拥有token
     * @param network
     * @param owner
     * @param spltoken
     * @returns {boolean}
     */
    async IsOwnToken(network, owner, spltoken) {
        try {
            var conn = new web3.Connection(rpcProviders[network], 'confirmed');
            const ownerPub = new web3.PublicKey(owner);
            const allTokenInfo = await conn.getParsedTokenAccountsByOwner(
                ownerPub,
                {
                    programId: splToken.TOKEN_PROGRAM_ID
                },
            );

        
            if (allTokenInfo.value === null || allTokenInfo.value === void 0) {
                return false;
            }

            for (var i = 0; i < allTokenInfo.value.length; i++) {
                /*
                if (allTokenInfo.value[i].pubkey.toBase58() == spltoken) {
                    return true
                }
                */
                if (allTokenInfo.value[i].account.data.parsed.info.mint == spltoken
                    && allTokenInfo.value[i].account.data.parsed.info.tokenAmount.amount == 1) {
                        return true
                }
            }

            return false;

        } catch (e) {
            throw e
        }
    },

    /**
     * get splToken 的  metadata
     * @param network
     * @param tokenAddress
     */
     async GetMetadataBytoken(network, tokenAddress) {
        try {
            var conn = new web3.Connection(rpcProviders[network], 'confirmed');
            var meta = await getMetadataByTokenAddress(conn, tokenAddress);
            if (meta == null || meta == void 0) {
                meta = null;
            }

            return meta;
        } catch (e) {
            throw e;
        }
    }
}

async function getSplTokenInfoByTokenAddress(conn, tokenAddress) {
    const tokenPubkey = new web3.PublicKey(tokenAddress);
    info['address'] = tokenPubkey.toString();
    //spl token info
    const tokeninfo = await conn.getParsedAccountInfo(tokenPubkey);
    if (tokeninfo != null && tokeninfo != void 0 && tokeninfo.value != null) {
        try {
            let infoJson = JSON.parse(JSON.stringify(tokeninfo));
            let decimals = infoJson.value.data.parsed.info.decimals;
            let program = infoJson.value.data.program;
            let supply = infoJson.value.data.parsed.info.supply;
            let freezeAuthority = infoJson.value.data.parsed.info.freezeAuthority;
            let mintAuthority = infoJson.value.data.parsed.info.mintAuthority;
            
            if (program == PROGRAM 
                && decimals == 0 
                && supply == 1 
                && freezeAuthority == mintAuthority)
            {
                info["result"] = 1;
                return info;
            }
        } catch (e) {
            throw e;
        }
    }

    info["result"] = 0;
    return info;
}

async function getMetadataByTokenAddress(conn, spltoken) {
    try {
        /* get token info first */
        let tokenInfo = await getSplTokenInfoByTokenAddress(conn, spltoken);
        /* if return ok */
        if (tokenInfo["result"] == 1) {
            /* get pubkey */
            const tokenPub = new web3.PublicKey(spltoken);
            //meta account
            const mAccount = await metadata.Metadata.getPDA(tokenPub);
            //await programs.metadata.Metadata.getPDA(tokenPub);
            //load metadata info
            const meta = await metadata.Metadata.load(conn, mAccount);
            //programs.metadata.load(conn, mAccount);

            if (METAPLEX_ACCOUNT == meta.info.owner.toBase58()){
                let creator = meta.toJSON().data.data.creators;
                let url = meta.toJSON().data.data.uri;

                return {
                    address:tokenInfo['address'],
                    decimals:tokenInfo['decimals'],
                    supply:tokenInfo['supply'],
                    type:tokenInfo['type'],
                    program:tokenInfo['program'], 
                    url:url,
                    creator:creator
                };
            }
        }
    } catch (e) {
        throw e
    }

    return null;
}
