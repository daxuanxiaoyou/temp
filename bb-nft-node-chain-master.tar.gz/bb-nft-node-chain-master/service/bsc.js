const ethers = require('ethers');
const Web3 = require('web3');
const math = require('mathjs');
const CODES = require('../enums/CodeEnums');

const PROVIDER = 'https://bsc-dataseed1.ninicoin.io';

module.exports = {
    async estimateGas(gasLimit) {
        try {
            const web3 = new Web3(PROVIDER);
            //get gasPrice
            let gasPrice = await web3.eth.getGasPrice();
            let costBase = math.multiply(gasLimit, gasPrice);
            costBase = ethers.utils.formatEther(costBase);
            //up 20%
            const adjustCost = math.multiply(costBase, 1.2);
            return adjustCost.toString();
        } catch (e) {
            throw e;
        }
    },

    /**
     * check tx status
     **/
     async txStatus(hash) {
        try {
            const web3 = new Web3(PROVIDER);
            if (hash.length != 66 || !hash.startsWith('0x')) {
                return CODES.ERRORS.INVALID_HASH;
            }

            const result = web3.eth.getTransactionReceipt(hash).then((receipt) => {

                if (receipt == null || receipt == undefined) {
                    //pending state
                    return CODES.RESULT.TX_PENDING;
                }
                
                //success
                if (receipt.status == 1) {
                    return CODES.RESULT.TX_SUCCESS;
                }
                //failed
                return CODES.RESULT.TX_FAILED;

            });
            return result;
        } catch (e) {
            throw e;
        }
    }
}