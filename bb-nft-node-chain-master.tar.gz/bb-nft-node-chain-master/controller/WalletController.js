const express = require('express');
const router = express.Router();
const eth = require('../service/eth');
const tezos = require('../service/tezos');
const klay = require('../service/klay');
const Result = require('../dto/Result');
const CODES = require('../enums/CodeEnums');
const Web3 = require('web3');
const caver = require('caver-js');
const bsc = require('../service/bsc');
const matic = require('../service/matic');
const solana = require('../service/solana');
//the gas limit of 721 contract: safeTransferFrom
const GAS_LIMIT = 220000;

const NETWORK = {
    ETH: eth,
    BSC: bsc,
    SOLANA: solana,
    MATIC: matic,
    TEZOS: tezos,
    KLAYTN: klay
};

router.post("/checkAddress", function (req, res) {
    let network = req.body.network.trim();
    let address = req.body.address.trim();

    network = network.toUpperCase();

    let result = false;
    switch (network) {
        case "ETH":
        case "BSC":
        case "MATIC":
            let newAddr = Web3.utils.toChecksumAddress(address);
            result = eth.checkAddress(newAddr);
            break;
        case "SOLANA":
            result = solana.checkAddress(address);
            break;
        case "TEZOS":
            result = tezos.checkAddress(address);
            break;
        case "KLAYTN":
            let checkSum = caver.utils.toChecksumAddress(address);
            result = klay.checkAddress(checkSum);
            break;
    }

    res.json(Result.success(result));
});

router.post("/verifySignature", function (req, res) {
    let network = req.body.network.trim();
    let address = req.body.address.trim();
    let signedText = req.body.signedText.trim();
    let sign = req.body.signature.trim();

    //trim
    address = address.trim();

    network = network.toUpperCase();

    let result = false;
    switch (network) {
        case "ETH":
        case "BSC":
            result = eth.verifySignature(signedText, sign);
            if (result === false || result == null) {
                res.json(Result.fail(CODES.ERRORS.SIGN_CHECK_ERROR.getCode(), CODES.ERRORS.SIGN_CHECK_ERROR.getDesc()))
            } else if (eth.checkAddress(result) || result === address) {
                res.json(Result.success(result));
            } else {
                res.json(Result.fail(CODES.ERRORS.SIGN_CHECK_ERROR.getCode(), CODES.ERRORS.SIGN_CHECK_ERROR.getDesc()))
            }
            break;
        case "SOLANA":
            result = true;
            res.json(Result.success(result));
            break
    }
});

router.post("/estimateGas", function (req, res) {
    let network = req.body.network.trim();

    network = network.toUpperCase();

    try {
        switch (network) {
            case "ETH":
            case "BSC":
            case "MATIC":
            case "KLAYTN":
                const web = NETWORK[network];
                web.estimateGas(GAS_LIMIT).then(
                    result => res.json(Result.success(result))
                ).catch(err =>{
                    res.json(Result.fail(CODES.ERRORS.ESTIMATEGAS_ERROR.getCode(), CODES.ERRORS.ESTIMATEGAS_ERROR.getDesc()))
                });
                break;
            case "SOLANA":
                solana.estimateGas().then(
                    result => res.json(Result.success(result))
                ).catch(err =>{
                    res.json(Result.fail(CODES.ERRORS.ESTIMATEGAS_ERROR.getCode(), CODES.ERRORS.ESTIMATEGAS_ERROR.getDesc()))
                });
                break;
            case "TEZOS":
                let result = tezos.estimateGas();
                res.json(Result.success(result));
                break;
            default:
                res.json(Result.fail(CODES.ERRORS.INVALID_NETWORK.getCode(), CODES.ERRORS.INVALID_NETWORK.getDesc()));
        }
    } catch (err) {
        res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()));
    }
});

router.post("/txStatus", function (req, res) {
    let network = req.body.network.trim();
    let hash = req.body.txhash.trim();
    network = network.toUpperCase();

    const web = NETWORK[network];

    if (web == null || web == undefined) {
        res.json(Result.fail(CODES.ERRORS.INVALID_NETWORK.getCode(), CODES.ERRORS.INVALID_NETWORK.getDesc()));
        return;
    }

    try {
        web.txStatus(hash).then(
            result => res.json(Result.success(0, result.getCode(), result.getDesc()))
        ).catch(err =>{
            res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()))
        });
    } catch (err) {
        res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()));
    }
});


module.exports = router;