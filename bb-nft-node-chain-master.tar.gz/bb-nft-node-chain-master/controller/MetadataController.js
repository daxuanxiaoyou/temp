const express = require('express');
const metadata = require('../service/metadata');
const tezos = require('../service/tezos');
const uploadService = require('../service/uploadIpfs');
const Result = require('../dto/Result');
const CODES = require('../enums/CodeEnums');

const metadataRouter = express.Router();



/* GET metadata */
metadataRouter.post('/checkOwner', function(req, res, next) {
  let network = req.body.network.trim();
  let owner = req.body.owner.trim();
  let token = req.body.token.trim();

  network = network.toUpperCase();
  try {

    switch (network) {
        case "SOL":
            metadata.IsOwnToken(network, owner, token).then(
                result => res.json(Result.success(result))
            ).catch(err =>{
                res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()))
            });
            
            break;
        }
  } catch (e) {
    res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()));
  }
});


metadataRouter.post('/token', function(req, res, next) {
  let network = req.body.network.trim();
  let tokenAddress = req.body.token.trim();

  network = network.toUpperCase();
  try {

    switch (network) {
        case "SOL":
            metadata.GetMetadataBytoken(network, tokenAddress).then(
                data => {
                    res.json(Result.success(data))
                }
            ).catch(err =>{
                res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()))
            });
            
            break;
    }
  } catch (e) {
    res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()));
  }
});


/* 
##check is mint
0 - not need
1 - need
*/
metadataRouter.post('/isMint', function(req, res, next) {
  let network = req.body.network.trim();
  let contract = req.body.contract.trim();
  let token = req.body.tokenid.trim();

  network = network.toUpperCase();
  try {

    switch (network) {
        case "TEZOS":
            tezos.isMint("main", contract, token).then(
                result => res.json(Result.success(result == true ? 0 : 1))
            ).catch(err =>{
                res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()))
            });
            
            break;
        }
  } catch (e) {
    res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()));
  }
});


metadataRouter.post('/tokenUri', function(req, res, next) {
    let network = req.body.network.trim();
    let contract = req.body.contract.trim();
    let token = req.body.tokenid.trim();

    network = network.toUpperCase();
    try {

        switch (network) {
            case "TEZOS":
                tezos.getTokenMetadata("main", contract, token).then(
                    data => {
                        res.json(Result.success(data))
                    }
                ).catch(err =>{
                    res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()))
                });
                
                break;
        }
    } catch (e) {
        res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()));
    }
});

metadataRouter.post('/balance', function(req, res, next) {
    let network = req.body.network.trim();
    let contract = req.body.contract.trim();
    let wallet = req.body.wallet.trim();
  
    network = network.toUpperCase();
    try {
  
      switch (network) {
          case "TEZOS":
              tezos.getBalance("main", contract, wallet).then(
                  result => res.json(Result.success(result))
              ).catch(err =>{
                  res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()))
              });
              
              break;
          }
    } catch (e) {
      res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()));
    }
  });


metadataRouter.post('/uploadMetedata', function(req, res, next) {
    let network = req.body.network.trim();
    let tokenId = req.body.tokenid.trim();
    let name = req.body.name;
    let symbol = req.body.symbol;
    let desc = req.body.desc;
    let type = req.body.type;
    let imageUrl = req.body.imageUrl;
    let thumbUrl = req.body.thumbUrl;
  
    network = network.toUpperCase();
    try {
  
      switch (network) {
          case "TEZOS":
              uploadService.uploadFile(tokenId, name, symbol, desc, type, imageUrl, thumbUrl).then(
                  result => {
                      let uri = 'ipfs://' + result;
                      res.json(Result.success(uri))
                  }
              ).catch(err =>{
                  res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()))
              });
              
              break;
          }
    } catch (e) {
      res.json(Result.fail(CODES.ERRORS.INTERNAL_ERROR.getCode(), CODES.ERRORS.INTERNAL_ERROR.getDesc()));
    }
  });

module.exports = metadataRouter;
